# import the necessary packages
from transform import four_point_transform
from coordinates import calculatePicture, calculateUniqueId, calculateFirstname, calculateLastname, calculateBirthdate, calculateGender, calculatetl, calculatetr, calculatebl
from extractor import get_photo, get_unique_id, get_firstname, get_lastname, get_dob, get_gender
from skimage.filters import threshold_local
import numpy as np
import argparse
import cv2
import imutils
from reader import getNameText, getObjectID
# construct the argument parser and parse the arguments
ap = argparse.ArgumentParser()
ap.add_argument("-i", "--image", required = True,
	help = "Path to the image to be scanned")
args = vars(ap.parse_args())

# load the image and compute the ratio of the old height
# to the new height, clone it, and resize it
image = cv2.imread(args["image"])
ratio = image.shape[0] / 500.0
orig = image.copy()
image = imutils.resize(image, height = 500)
clone = image.copy()
# convert the image to grayscale, blur it, and find edges
# in the image
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
gray = cv2.GaussianBlur(gray, (3, 3), 0)
#  Use Canny algorithm to detect edge
edged = cv2.Canny(gray, 75, 200)

# show the original image and the edge detected image
print("STEP 1: Edge Detection")
cv2.imshow("Image", image)
cv2.imshow("Edged", edged)
cv2.waitKey(0)
cv2.destroyAllWindows()

# find the contours in the edged image, keeping only the
# largest ones, and initialize the screen contour
cnts = cv2.findContours(edged.copy(), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
cnts = imutils.grab_contours(cnts)
cnts = sorted(cnts, key = cv2.contourArea, reverse = True)[:5]

# loop over the contours
for c in cnts:
	# approximate the contour
	peri = cv2.arcLength(c, True)
	approx = cv2.approxPolyDP(c, 0.05 * peri, True)

	# if our approximated contour has four points, then we
	# can assume that we have found our screen
	if len(approx) == 4:
		print(peri)
		screenCnt = approx
		break
# L = (62.5 * (peri/2))/100 
# l = peri - L
# addL = int((387.73*L) / 100)
# addl = int((19.50 * l)/100)
# # show the contour (outline) of the piece of paper
# print("STEP 2: Find contours of paper")

# screenCnt[0][0][0] = screenCnt[0][0][0] - addL
# screenCnt[0][0][1] = screenCnt[0][0][1] - addl
# print(screenCnt)
# # screenCnt[1][0] = [0,499]
# # screenCnt[2][0] = [778,498]
# # screenCnt[3][0] = [779, 7]
cv2.drawContours(image, [screenCnt], -1, (0, 255, 0), 2)

#print(screenCnt[0][0])
cv2.imshow("Outline", image)
cv2.waitKey(0)
cv2.destroyAllWindows()

# apply the four point transform to obtain a top-down
# view of the original image
warped = four_point_transform(orig, screenCnt.reshape(4, 2) * ratio)
clone = four_point_transform(orig, screenCnt.reshape(4, 2) * ratio)
# convert the warped image to grayscale, then threshold it
# to give it that 'black and white' paper effect
warped = cv2.cvtColor(warped, cv2.COLOR_BGR2GRAY)
T = threshold_local(warped, 11, offset = 10, method = "gaussian")
warped = (warped > T).astype("uint8") * 255

# show the original and scanned images
print("STEP 3: Apply perspective transform")
cv2.imshow("Original", imutils.resize(orig, height = 650))
final = imutils.resize(warped, height = 650)
clone = imutils.resize(clone, height = 650)
res = calculateGender(final)
name = calculateFirstname(final)
last = calculateLastname(final)
dob  = calculateBirthdate(final)
photo = calculatePicture(final)
# cv2.circle(final,(res[0][0], res[0][1]), 10, (0,255,0))
# cv2.circle(final,(res[1][0], res[1][1]), 10, (0,255,0))
# cv2.circle(final,(res[2][0], res[2][1]), 10, (0,255,0))
# cv2.circle(final,(res[3][0], res[3][1]), 10, (0,255,0))
cv2.rectangle(final, (photo[0][0], photo[0][1]), (photo[2][0], photo[2][1]), (0,255,0), 2)
cv2.rectangle(final, (res[0][0], res[0][1]), (res[2][0], res[2][1]), (0,255,0), 2)
cv2.rectangle(final, (name[0][0], name[0][1]), (name[2][0], name[2][1]), (0,255,0), 2)
cv2.rectangle(final, (last[0][0], last[0][1]), (last[2][0], last[2][1]), (0,255,0), 2)
cv2.rectangle(final, (dob[0][0], dob[0][1]), (dob[2][0], dob[2][1]), (0,255,0), 2)
# widthA = np.sqrt(((res[2][0] - res[3][0]) ** 2) + ((res[2][1] - res[3][1]) ** 2))
# heightA = np.sqrt(((res[1][0] - res[2][0]) ** 2) + ((res[1][1] - res[2][1]) ** 2))
# print(widthA)
# print(heightA)
print(getObjectID(clone))
crop_img = get_photo(clone) 

gray = cv2.cvtColor(crop_img, cv2.COLOR_BGR2GRAY)
gray = cv2.threshold(gray, 20, 255,cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]
cv2.imwrite("test.png", crop_img)
#getNameText(gray)
#=====================================

# mask = np.zeros(clone.shape, dtype=np.uint8)
# roi =  np.array([res], dtype=np.int32)
# channel_count = image.shape[2]  # i.e. 3 or 4 depending on your image
# ignore_mask_color = (255,)*channel_count
# cv2.fillPoly(mask, roi, ignore_mask_color)
# masked_image = cv2.bitwise_and(clone, mask)

#========================================
#print(crop_img)
cv2.imshow("Scanned", final)
cv2.waitKey(0)