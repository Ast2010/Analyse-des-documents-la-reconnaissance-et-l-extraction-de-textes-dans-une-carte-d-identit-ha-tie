import math
def calculatePicture(image):
    res = []
    res.append(calculateTopLeft(image))
    res.append(calculateTopRight(image))
    res.append(calculateBottomRight(image))
    res.append(calculateBottomLeft(image))
    return res
def calculatePercent(x, p):
    return int(round((p * x) / 100))

def calculateTopLeft(img):
    imgX, imgY = img.shape[:2]
    x1 = calculatePercent(imgX, 6.46)
    y1 = calculatePercent(imgY, 4.66)
    # print((y1,x1))
    return (y1,x1)

def calculateTopRight(img):
    imgX, imgY = img.shape[:2]
    x1 = calculatePercent(imgX, 7.50)
    y1 = calculatePercent(imgY, 37.31)
    # print((y1,x1))
    return (y1, x1)

def calculateBottomRight(img):
    imgX, imgY = img.shape[:2]
    x1 = calculatePercent(imgX, 75.07)
    y1 = calculatePercent(imgY, 36.31)
    # print((y1,x1))
    return (y1, x1)

def calculateBottomLeft(img):
    imgX, imgY = img.shape[:2]
    x1 = calculatePercent(imgX, 75.07)
    y1 = calculatePercent(imgY, 3.61)
    # print((y1,x1))
    return (y1, x1)

def calculateUniqueId(image):
    res = []
    imgX, imgY = image.shape[:2]
    res.append((calculatePercent(imgY, 39.64), calculatePercent(imgX,24.61)))
    res.append((calculatePercent(imgY, 77.14), calculatePercent(imgX,24.61)))
    res.append((calculatePercent(imgY, 77.14), calculatePercent(imgX,31.76)))
    res.append((calculatePercent(imgY, 39.64), calculatePercent(imgX,30.76)))
    return res

def calculateFirstname(image):
    res = []
    imgX, imgY = image.shape[:2]
    res.append((calculatePercent(imgY, 37.64), calculatePercent(imgX,35.15)))
    res.append((calculatePercent(imgY, 77.14), calculatePercent(imgX,35.15)))
    res.append((calculatePercent(imgY, 77.14), calculatePercent(imgX,42.23)))
    res.append((calculatePercent(imgY, 37.64), calculatePercent(imgX,41.23)))
    return res

def calculateLastname(image):
    res = []
    imgX, imgY = image.shape[:2]
    res.append((calculatePercent(imgY, 37.64), calculatePercent(imgX,45.53)))
    res.append((calculatePercent(imgY, 77.14), calculatePercent(imgX,45.53)))
    res.append((calculatePercent(imgY, 77.14), calculatePercent(imgX,50.46)))
    res.append((calculatePercent(imgY, 37.64), calculatePercent(imgX,51.46)))
    return res

def calculateBirthdate(image):
    res = []
    imgX, imgY = image.shape[:2]
    res.append((calculatePercent(imgY, 37.64), calculatePercent(imgX,55.07)))
    res.append((calculatePercent(imgY, 56.14), calculatePercent(imgX,55.07)))
    res.append((calculatePercent(imgY, 56.14), calculatePercent(imgX,60.46)))
    res.append((calculatePercent(imgY, 37.64), calculatePercent(imgX,61.46)))
    return res

def calculateGender(image):
    res = []
    imgX, imgY = image.shape[:2]
    res.append((calculatePercent(imgY, 72.64), calculatePercent(imgX,54.57)))
    res.append((calculatePercent(imgY, 81.71), calculatePercent(imgX,54.57)))
    res.append((calculatePercent(imgY, 81.71), calculatePercent(imgX,61.46)))
    res.append((calculatePercent(imgY, 72.64), calculatePercent(imgX,62.46)))
    return res

def calculatetl(X, Y, image):
    imgX, imgY = image.shape[:2]
    x = int(X - calculatePercent(imgY, 78.70))
    y = int(Y - calculatePercent(imgX, 13))
    #print((x,y))
    return (y, x)

def calculatetr(X, Y, image):
    imgX, imgY = image.shape[:2]
    x = int(X - calculatePercent(imgY, 0.1))
    y = int(Y - calculatePercent(imgX, 10))
    #print((x,y))
    return (x, y)

def calculatebl(X, Y, image):
    imgX, imgY = image.shape[:2]
    x = int(X - calculatePercent(imgY, 100))
    y = int(Y - calculatePercent(imgX, 66))
    #print((x,y))
    return (y, x)
