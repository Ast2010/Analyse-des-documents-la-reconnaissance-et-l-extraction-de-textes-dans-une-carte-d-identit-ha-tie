from coordinatesvn import calculatePicture, calculateUniqueId, calculateFirstname, calculateLastname, calculateBirthdate, calculateGender
import numpy as np
import cv2

def get_photo(image):
    res = calculatePicture(image)
    return image[res[0][0]:(res[2][1] - res[0][1]), res[0][1]:(res[2][0] - res[0][0])]

def get_unique_id(image):
    res = calculateUniqueId(image)
    return image[res[0][1]:res[3][1], res[0][0]:res[1][0]]

def get_firstname(image):
    res = calculateFirstname(image)
    return image[res[0][1]:res[3][1], res[0][0]:res[1][0]]    

def get_lastname(image):
    res = calculateLastname(image)
    return image[res[0][1]:res[3][1], res[0][0]:res[1][0]]    


def get_dob(image):
    res = calculateBirthdate(image)
    return image[res[0][1]:res[3][1], res[0][0]:res[1][0]]   

def get_gender(image):
    res = calculateGender(image)
    return image[res[0][1]:res[3][1], res[0][0]:res[1][0]]   