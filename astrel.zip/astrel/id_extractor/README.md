### ID EXTRACTOR
Extract information from Haitian National ID Card