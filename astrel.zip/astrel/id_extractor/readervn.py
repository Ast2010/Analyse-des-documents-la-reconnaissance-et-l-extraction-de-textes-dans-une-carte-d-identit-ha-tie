# import the necessary packages
from PIL import Image
import pytesseract
import cv2
import os
from extractorvn import get_firstname, get_lastname, get_dob, get_gender, get_unique_id
import json

def getNameText(img):
    image = img
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    gray = cv2.threshold(gray, 20, 255,cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]
    filename = "{}.png".format(os.getpid())
    cv2.imwrite(filename, gray)
    text = pytesseract.image_to_string(Image.open(filename), lang='vie')
    os.remove(filename)
    print(text)
    return text

def getNameBlur(img):
    image = img
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    gray =  cv2.threshold(gray, 0, 255,cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]
    filename = "{}.png".format(os.getpid())
    cv2.imwrite(filename, gray)
    custom_oem_psm_config = r'--psm 6'
    text = pytesseract.image_to_string(Image.open(filename), config=custom_oem_psm_config, lang='vie')
    os.remove(filename)
    print(text)
    return text

def getNameGender(img):
    image = img
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    gray =  cv2.threshold(gray, 75, 200,cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]
    filename = "{}.png".format(os.getpid())
    cv2.imwrite(filename, gray)
    custom_oem_psm_config = r'--psm 8'
    text = pytesseract.image_to_string(Image.open(filename), config=custom_oem_psm_config, lang='vie')
    os.remove(filename)
    print(text)
    return text

def getObjectID(image):
    user = {
        "uniqueID" : getNameText(get_unique_id(image)),
        "name" : getNameBlur(get_firstname(image)),
        "birthday" : getNameText(get_dob(image)),
        "gender" : getNameBlur(get_gender(image))
     }
    return json.dumps(user)