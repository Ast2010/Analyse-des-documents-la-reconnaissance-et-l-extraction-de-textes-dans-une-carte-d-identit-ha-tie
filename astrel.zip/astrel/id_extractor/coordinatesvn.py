import math
def calculatePicture(image):
    res = []
    res.append(calculateTopLeft(image))
    res.append(calculateTopRight(image))
    res.append(calculateBottomRight(image))
    res.append(calculateBottomLeft(image))
    return res
def calculatePercent(x, p):
    return int(round((p * x) / 100))

def calculateTopLeft(img):
    imgX, imgY = img.shape[:2]
    x1 = calculatePercent(imgX, 36.61)
    y1 = calculatePercent(imgY, 4.629)
    # print((y1,x1))
    return (y1,x1)

def calculateTopRight(img):
    imgX, imgY = img.shape[:2]
    x1 = calculatePercent(imgX, 36.61)
    y1 = calculatePercent(imgY, 31.944)
    # print((y1,x1))
    return (y1, x1)

def calculateBottomRight(img):
    imgX, imgY = img.shape[:2]
    x1 = calculatePercent(imgX, 93.846)
    y1 = calculatePercent(imgY, 31.944)
    # print((y1,x1))
    return (y1, x1)

def calculateBottomLeft(img):
    imgX, imgY = img.shape[:2]
    x1 = calculatePercent(imgX, 36.615)
    y1 = calculatePercent(imgY, 4.629)
    # print((y1,x1))
    return (y1, x1)

def calculateUniqueId(image):
    res = []
    imgX, imgY = image.shape[:2]
    res.append((calculatePercent(imgY, 45), calculatePercent(imgX,25.538)))
    res.append((calculatePercent(imgY, 88.98), calculatePercent(imgX,25.538)))
    res.append((calculatePercent(imgY, 88.98), calculatePercent(imgX,36.92)))
    res.append((calculatePercent(imgY, 45), calculatePercent(imgX,36.92)))
    return res

def calculateFirstname(image):
    res = []
    imgX, imgY = image.shape[:2]
    res.append((calculatePercent(imgY, 45), calculatePercent(imgX,40)))
    res.append((calculatePercent(imgY, 88.98), calculatePercent(imgX,40)))
    res.append((calculatePercent(imgY, 88.98), calculatePercent(imgX,52.30)))
    res.append((calculatePercent(imgY, 45), calculatePercent(imgX,53.30)))
    return res

def calculateLastname(image):
    res = []
    imgX, imgY = image.shape[:2]
    res.append((calculatePercent(imgY, 39.64), calculatePercent(imgX,45.53)))
    res.append((calculatePercent(imgY, 77.14), calculatePercent(imgX,45.53)))
    res.append((calculatePercent(imgY, 77.14), calculatePercent(imgX,50.46)))
    res.append((calculatePercent(imgY, 39.64), calculatePercent(imgX,51.46)))
    return res

def calculateBirthdate(image):
    res = []
    imgX, imgY = image.shape[:2]
    res.append((calculatePercent(imgY, 59.62), calculatePercent(imgX,50.15)))
    res.append((calculatePercent(imgY, 86.75), calculatePercent(imgX,50.15)))
    res.append((calculatePercent(imgY, 86.75), calculatePercent(imgX,60.30)))
    res.append((calculatePercent(imgY, 59.62), calculatePercent(imgX,60.30)))
    return res

def calculateGender(image):
    res = []
    imgX, imgY = image.shape[:2]
    res.append((calculatePercent(imgY, 43.98), calculatePercent(imgX,59.23)))
    res.append((calculatePercent(imgY, 55.55), calculatePercent(imgX,59.23)))
    res.append((calculatePercent(imgY, 55.55), calculatePercent(imgX,68.46)))
    res.append((calculatePercent(imgY, 43.98), calculatePercent(imgX,68.46)))
    return res

def calculatetl(X, Y, image):
    imgX, imgY = image.shape[:2]
    x = int(X - calculatePercent(imgY, 78.70))
    y = int(Y - calculatePercent(imgX, 13))
    #print((x,y))
    return (y, x)

def calculatetr(X, Y, image):
    imgX, imgY = image.shape[:2]
    x = int(X - calculatePercent(imgY, 0.1))
    y = int(Y - calculatePercent(imgX, 10))
    #print((x,y))
    return (x, y)

def calculatebl(X, Y, image):
    imgX, imgY = image.shape[:2]
    x = int(X - calculatePercent(imgY, 100))
    y = int(Y - calculatePercent(imgX, 66))
    #print((x,y))
    return (y, x)
